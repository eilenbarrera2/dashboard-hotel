import 'react-native-gesture-handler';
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useNavigation } from '@react-navigation/native';
import { Image, View, TouchableOpacity, Text } from 'react-native';

// Pantallas (¡asegúrate de importar las siguientes correctamente!)
import HomeScreen from './screens/HomeScreen';
import RoomScreen from './screens/RoomScreen';
import ServicesScreen from './screens/Services';
import BookingScreen from './screens/Booking';

// 1. Define los tipos de navegación
type RootStackParamList = {
  Home: undefined;
  Habitaciones: undefined;
  Servicios: undefined;
  Reservar: undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();

// 2. CustomHeader usando useNavigation con tipado correcto
const CustomHeader = () => {
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();

  return (
    <View
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 15,
        paddingVertical: 10,
        backgroundColor: 'white',
        borderBottomWidth: 1,
        borderBottomColor: '#eee',
      }}
    >
      {/* Logo */}
      <Image
        source={require('./assets/logo.jpg')}
        style={{ width: 50, height: 50, marginRight: 15 }}
      />

      {/* Navegación */}
      <TouchableOpacity onPress={() => navigation.navigate('Home')}>
        <Text style={{ marginHorizontal: 10 }}>Inicio</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => navigation.navigate('Habitaciones')}>
        <Text style={{ marginHorizontal: 10 }}>Habitaciones</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => navigation.navigate('Servicios')}>
        <Text style={{ marginHorizontal: 10 }}>Servicios</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => navigation.navigate('Reservar')}>
        <Text style={{ marginHorizontal: 10, fontWeight: 'bold' }}>Reservar ahora</Text>
      </TouchableOpacity>

      {/* Botones derecha */}
      <View style={{ flex: 1 }} />
      <TouchableOpacity
        style={{
          backgroundColor: '#4267B2',
          paddingHorizontal: 10,
          paddingVertical: 8,
          borderRadius: 5,
          marginRight: 10,
        }}
      >
        <Text style={{ color: 'white' }}>Iniciar sesión</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={{
          backgroundColor: '#4267B2',
          paddingHorizontal: 10,
          paddingVertical: 8,
          borderRadius: 5,
        }}
      >
        <Text style={{ color: 'white' }}>Regístrate</Text>
      </TouchableOpacity>
    </View>
  );
};

// 3. App principal
export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName="Home"
        screenOptions={{
          header: () => <CustomHeader />,
        }}
      >
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="Habitaciones" component={RoomScreen} />
        <Stack.Screen name="Servicios" component={ServicesScreen} />
        <Stack.Screen name="Reservar" component={BookingScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
