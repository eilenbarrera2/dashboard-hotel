import 'react-native-gesture-handler';
import React, { useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useNavigation } from '@react-navigation/native';
import {
  Image,
  View,
  TouchableOpacity,
  Text,
  StyleSheet,
  Dimensions,
  Modal,
  TouchableWithoutFeedback,
  Platform,
  StatusBar
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

// Importar el AuthProvider
import { AuthProvider, useAuth } from './AuthContext';

// Pantallas
import HomeScreen from './screens/HomeScreen';
import RoomScreen from './screens/RoomScreen';
import ServicesScreen from './screens/Services';
import BookingScreen from './screens/Booking';
import LoginScreen from './screens/LoginC';
import RegisterScreen from './screens/Register';
import ForgotPasswordScreen from './screens/ForgotPassword';
import ConfirmBooking from './screens/ConfirmBooking';
import DashboardScreen from './screens/DashboardCustom'; // Asegúrate de crear este archivo
import PaymentScreen from './screens/PaymentScreen';

type RootStackParamList = {
  Home: undefined;
  Habitaciones: undefined;
  Servicios: undefined;
  Reservar: undefined;
  IniciarSesion: undefined;
  Registrate: undefined;
  ForgotPassword: undefined;
  ConfirmBooking: undefined;
  Dashboard: undefined;
  PaymentScreen: undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();
const { width } = Dimensions.get('window');

// Mueve el CustomHeader a un archivo separado o déjalo aquí pero con una verificación
const CustomHeader = () => {
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const [menuVisible, setMenuVisible] = useState(false);
  const { user, isAuthenticated, logout } = useAuth();

  const toggleMenu = () => {
    setMenuVisible(!menuVisible);
  };

  const navigateTo = (screen: keyof RootStackParamList) => {
    navigation.navigate(screen);
    setMenuVisible(false);
  };

  const handleLogout = () => {
    logout();
    setMenuVisible(false);
    navigation.navigate('Home');
  };

  return (
    <View style={styles.headerContainer}>
      {/* Logo */}
      <Image
        source={require('./assets/logo.jpg')}
        style={styles.logo}
      />

      {/* Botón de menú hamburguesa */}
      <TouchableOpacity onPress={toggleMenu} style={styles.menuButton}>
        <Ionicons name="menu" size={28} color="#000" />
      </TouchableOpacity>

      {/* Navegación para tablets */}
      {width >= 768 && (
        <View style={styles.desktopNav}>
          <TouchableOpacity onPress={() => navigation.navigate('Home')}>
            <Text style={styles.navLink}>Inicio</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => navigation.navigate('Habitaciones')}>
            <Text style={styles.navLink}>Habitaciones</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => navigation.navigate('Servicios')}>
            <Text style={styles.navLink}>Servicios</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => navigation.navigate('Reservar')}>
            <Text style={[styles.navLink, styles.reserveNow]}>Reservar ahora</Text>
          </TouchableOpacity>

          <View style={styles.authButtons}>
            {isAuthenticated ? (
              <>
                <TouchableOpacity
                  onPress={() => navigation.navigate('Dashboard')}
                  style={styles.authButton}
                >
                  <Text style={styles.authButtonText}>{user?.name}</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={handleLogout}
                  style={[styles.authButton, styles.logoutButton]}
                >
                  <Text style={styles.authButtonText}>Cerrar sesión</Text>
                </TouchableOpacity>
              </>
            ) : (
              <>
                <TouchableOpacity
                  onPress={() => navigation.navigate('IniciarSesion')}
                  style={styles.authButton}
                >
                  <Text style={styles.authButtonText}>Iniciar sesión</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => navigation.navigate('Registrate')}
                  style={styles.authButton}
                >
                  <Text style={styles.authButtonText}>Regístrate</Text>
                </TouchableOpacity>
              </>
            )}
          </View>
        </View>
      )}

      {/* Modal del menú para móviles */}
      <Modal
        visible={menuVisible}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setMenuVisible(false)}
      >
        <TouchableWithoutFeedback onPress={() => setMenuVisible(false)}>
          <View style={styles.modalOverlay} />
        </TouchableWithoutFeedback>

        <View style={styles.mobileMenu}>
          <View style={styles.menuHeader}>
            <Image
              source={require('./assets/logo.jpg')}
              style={styles.menuLogo}
            />
            <TouchableOpacity onPress={() => setMenuVisible(false)} style={styles.closeButton}>
              <Ionicons name="close" size={28} color="#000" />
            </TouchableOpacity>
          </View>

          <View style={styles.menuItems}>
            <TouchableOpacity onPress={() => navigateTo('Home')} style={styles.menuItem}>
              <Ionicons name="home" size={20} color="#4267B2" style={styles.menuIcon} />
              <Text style={styles.menuText}>Inicio</Text>
            </TouchableOpacity>

            <TouchableOpacity onPress={() => navigateTo('Habitaciones')} style={styles.menuItem}>
              <Ionicons name="bed" size={20} color="#4267B2" style={styles.menuIcon} />
              <Text style={styles.menuText}>Habitaciones</Text>
            </TouchableOpacity>

            <TouchableOpacity onPress={() => navigateTo('Servicios')} style={styles.menuItem}>
              <Ionicons name="star" size={20} color="#4267B2" style={styles.menuIcon} />
              <Text style={styles.menuText}>Servicios</Text>
            </TouchableOpacity>

            <TouchableOpacity onPress={() => navigateTo('Reservar')} style={styles.menuItem}>
              <Ionicons name="calendar" size={20} color="#4267B2" style={styles.menuIcon} />
              <Text style={[styles.menuText, styles.menuReserve]}>Reservar ahora</Text>
            </TouchableOpacity>

            <View style={styles.menuDivider} />

            {isAuthenticated ? (
              <>
                <TouchableOpacity
                  onPress={() => navigateTo('Dashboard')}
                  style={[styles.menuItem, styles.authMenuItem]}
                >
                  <Ionicons name="person" size={20} color="#4267B2" style={styles.menuIcon} />
                  <Text style={styles.menuText}>{user?.name}</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={handleLogout}
                  style={[styles.menuItem, styles.authMenuItem]}
                >
                  <Ionicons name="log-out" size={20} color="#4267B2" style={styles.menuIcon} />
                  <Text style={styles.menuText}>Cerrar sesión</Text>
                </TouchableOpacity>
              </>
            ) : (
              <>
                <TouchableOpacity
                  onPress={() => navigateTo('IniciarSesion')}
                  style={[styles.menuItem, styles.authMenuItem]}
                >
                  <Ionicons name="log-in" size={20} color="#4267B2" style={styles.menuIcon} />
                  <Text style={styles.menuText}>Iniciar sesión</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => navigateTo('Registrate')}
                  style={[styles.menuItem, styles.authMenuItem]}
                >
                  <Ionicons name="person-add" size={20} color="#4267B2" style={styles.menuIcon} />
                  <Text style={styles.menuText}>Regístrate</Text>
                </TouchableOpacity>
              </>
            )}
          </View>
        </View>
      </Modal>
    </View>
  );
};

// Header simple para pantallas de autenticación
const SimpleHeader = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.headerContainer}>
      <Image
        source={require('./assets/logo.jpg')}
        style={styles.logo}
      />
      <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
        <Ionicons name="arrow-back" size={28} color="#000" />
      </TouchableOpacity>
    </View>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <NavigationContainer>
        <StatusBar barStyle="dark-content" />
        <Stack.Navigator
          initialRouteName="Home"
          screenOptions={{
            contentStyle: { backgroundColor: '#fff' }
          }}
        >
          <Stack.Screen
            name="Home"
            component={HomeScreen}
            options={{ header: () => <CustomHeader /> }}
          />
          <Stack.Screen
            name="Habitaciones"
            component={RoomScreen}
            options={{ header: () => <CustomHeader /> }}
          />
          <Stack.Screen
            name="Servicios"
            component={ServicesScreen}
            options={{ header: () => <CustomHeader /> }}
          />
          <Stack.Screen
            name="Reservar"
            component={BookingScreen}
            options={{ header: () => <CustomHeader /> }}
          />
          <Stack.Screen
            name="Dashboard"
            component={DashboardScreen}
            options={{ header: () => <CustomHeader /> }}
          />
          <Stack.Screen
            name="ConfirmBooking"
            component={ConfirmBooking}
            options={{ header: () => <CustomHeader /> }}
          />
          <Stack.Screen
            name="PaymentScreen"
            component={PaymentScreen}
            options={{ title: "Pago" }}
          />
          {/* Pantallas de autenticación con header simple */}
          <Stack.Screen
            name="IniciarSesion"
            component={LoginScreen}
            options={{ header: () => <SimpleHeader /> }}
          />
          <Stack.Screen
            name="Registrate"
            component={RegisterScreen}
            options={{ header: () => <SimpleHeader /> }}
          />
          <Stack.Screen
            name="ForgotPassword"
            component={ForgotPasswordScreen}
            options={{ header: () => <SimpleHeader /> }}
          />
        </Stack.Navigator>
      </NavigationContainer>
    </AuthProvider>
  );
}

const styles = StyleSheet.create({
  headerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 15,
    paddingVertical: 10,
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
    ...Platform.select({
      ios: {
        paddingTop: 50,
      },
      android: {
        paddingTop: 10,
      },
    }),
  },
  logo: {
    width: 50,
    height: 50,
  },
  backButton: {
    padding: 5,
  },
  menuButton: {
    padding: 5,
    ...Platform.select({
      web: {
        display: width >= 768 ? 'none' : 'flex',
      },
      default: {
        display: 'flex',
      },
    }),
  },
  desktopNav: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginLeft: 20,
    display: width >= 768 ? 'flex' : 'none',
  },
  navLink: {
    marginHorizontal: 10,
    color: '#333',
  },
  reserveNow: {
    fontWeight: 'bold',
    color: '#000000ff',
  },
  authButtons: {
    flexDirection: 'row',
  },
  authButton: {
    backgroundColor: '#4267B2',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 5,
    marginLeft: 10,
  },
  logoutButton: {
    backgroundColor: '#ff4757',
  },
  authButtonText: {
    color: 'white',
    fontSize: 14,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  mobileMenu: {
    position: 'absolute',
    top: 0,
    right: 0,
    backgroundColor: 'white',
    width: '80%',
    height: '100%',
    padding: 20,
  },
  menuHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 30,
  },
  menuLogo: {
    width: 50,
    height: 50,
  },
  closeButton: {
    padding: 5,
  },
  menuItems: {
    marginTop: 20,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  authMenuItem: {
    marginTop: 10,
  },
  menuIcon: {
    marginRight: 15,
  },
  menuText: {
    fontSize: 16,
    color: '#333',
  },
  menuReserve: {
    fontWeight: 'bold',
    color: '#E91E63',
  },
  menuDivider: {
    height: 1,
    backgroundColor: '#eee',
    marginVertical: 15,
  },
});