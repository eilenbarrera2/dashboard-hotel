import isEmpty from "lodash/isEmpty";
export default isEmpty;
