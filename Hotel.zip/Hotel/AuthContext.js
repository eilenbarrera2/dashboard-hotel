import React, { createContext, useContext, useState, useEffect } from 'react';

const AuthContext = createContext();

export const useAuth = () => {
    const context = useContext(AuthContext);
    if (!context) {
        // Retornar valores por defecto en lugar de lanzar error
        return {
            user: null,
            isAuthenticated: false,
            login: () => ({ success: false, error: 'Contexto no disponible' }),
            logout: () => { },
            register: () => ({ success: false, error: 'Contexto no disponible' })
        };
    }
    return context;
};

export const AuthProvider = ({ children }) => {
    const [user, setUser] = useState(null);
    const [isAuthenticated, setIsAuthenticated] = useState(false);

    // Datos mock para simular el backend
    const mockUsers = [
        { id: 1, email: 'cliente@ejemplo.com', password: '1234', name: 'Juan Pérez' },
        { id: 2, email: 'admin@example.com', password: '1234', name: 'Administrador' }
    ];

    // Cargar estado de autenticación desde AsyncStorage (opcional)
    useEffect(() => {
        // Aquí podrías cargar el estado de autenticación persistido
    }, []);

    const login = (email, password) => {
        // Simular validación con datos mock
        const foundUser = mockUsers.find(user =>
            user.email === email && user.password === password
        );

        if (foundUser) {
            setUser(foundUser);
            setIsAuthenticated(true);
            return { success: true, user: foundUser };
        } else {
            return { success: false, error: 'Credenciales incorrectas' };
        }
    };

    const logout = () => {
        setUser(null);
        setIsAuthenticated(false);
    };

    const register = (userData) => {
        // Simular registro
        const newUser = {
            id: Math.random() * 1000,
            ...userData
        };

        mockUsers.push(newUser);
        setUser(newUser);
        setIsAuthenticated(true);
        return { success: true, user: newUser };
    };

    const value = {
        user,
        isAuthenticated,
        login,
        logout,
        register
    };

    return (
        <AuthContext.Provider value={value}>
            {children}
        </AuthContext.Provider>
    );
};