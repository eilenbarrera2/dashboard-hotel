const { getDefaultConfig } = require("expo/metro-config");

const config = getDefaultConfig(__dirname);

config.resolver.extraNodeModules = {
    "lodash/isEmpty": require.resolve("./shim-lodash.js"),
};

module.exports = config;
