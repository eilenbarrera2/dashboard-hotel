import React, { useState } from "react";
import {
    View,
    Text,
    TextInput,
    TouchableOpacity,
    Image,
    StyleSheet,
    Alert,
    ScrollView,
    KeyboardAvoidingView,
    Platform,
    SafeAreaView
} from "react-native";
import { useNavigation } from "@react-navigation/native";


export default function ForgotPassword() {
    const [email, setEmail] = useState<string>("");
    const navigation = useNavigation<any>();

    const handleSubmit = () => {
        Alert.alert(
            "Recuperación",
            "Si el correo está registrado, recibirás un enlace de recuperación."
        );
        navigation.navigate("IniciarSesion");
    };

    return (
        <SafeAreaView style={styles.safeArea}>
            <KeyboardAvoidingView
                behavior={Platform.OS === "ios" ? "padding" : "height"}
                style={styles.keyboardAvoid}
            >
                <ScrollView
                    contentContainerStyle={styles.scrollContainer}
                    keyboardShouldPersistTaps="handled"
                >
                    <View style={styles.container}>
                        {/* Header */}
                        <View style={styles.header}>
                            <View style={styles.logoCircle}>
                                <Image source={require('./../assets/contraseña.png')} style={styles.logoImg} />
                            </View>
                            <Text style={styles.title}>Recuperar Contraseña</Text>
                            <Text style={styles.subtitle}>
                                Ingresa tu correo para restablecer tu contraseña
                            </Text>
                        </View>

                        {/* Form */}
                        <View style={styles.form}>
                            <Text style={styles.label}>Correo electrónico</Text>
                            <TextInput
                                style={styles.input}
                                placeholder="tu@email.com"
                                keyboardType="email-address"
                                autoCapitalize="none"
                                value={email}
                                onChangeText={setEmail}
                            />

                            <TouchableOpacity style={styles.sendButton} onPress={handleSubmit}>
                                <Text style={styles.sendButtonText}>Enviar enlace</Text>
                            </TouchableOpacity>

                            <View style={styles.loginOption}>
                                <Text style={styles.text}>¿Recordaste tu contraseña? </Text>
                                <TouchableOpacity onPress={() => navigation.navigate("IniciarSesion")}>
                                    <Text style={styles.linkText}>Inicia sesión</Text>
                                </TouchableOpacity>
                            </View>
                        </View>
                    </View>
                </ScrollView>
            </KeyboardAvoidingView>
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    safeArea: {
        flex: 1,
        backgroundColor: "#eef3ff",
    },
    keyboardAvoid: {
        flex: 1,
    },
    scrollContainer: {
        flexGrow: 1,
        justifyContent: "center",
    },
    container: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
        paddingHorizontal: 20,
    },
    header: { alignItems: "center", marginBottom: 20 },
    logoCircle: {
        justifyContent: "center",
        alignItems: "center",
        backgroundColor: "#002a7f",
        width: 70,
        height: 70,
        borderRadius: 35,
        marginBottom: 10,
    },
    logoImg: { width: 50, height: 50, resizeMode: "contain" },
    title: { fontSize: 24, fontWeight: "bold", color: "#060e3a" },
    subtitle: { fontSize: 16, color: "#3d4046" },
    form: {
        backgroundColor: "white",
        padding: 25,
        borderRadius: 15,
        width: "100%",
        maxWidth: 350,
        shadowColor: "#000",
        shadowOpacity: 0.1,
        shadowRadius: 10,
        elevation: 3,
    },
    label: { fontSize: 16, fontWeight: "600", color: "#060e3a", marginTop: 10 },
    input: {
        borderWidth: 1,
        borderColor: "#cbd5e1",
        borderRadius: 10,
        padding: 10,
        marginTop: 5,
        marginBottom: 10,
        height: 45,
    },
    sendButton: {
        backgroundColor: "#002a7f",
        padding: 12,
        borderRadius: 12,
        alignItems: "center",
        marginTop: 10,
    },
    sendButtonText: { color: "white", fontWeight: "bold", fontSize: 15 },
    loginOption: {
        flexDirection: "row",
        justifyContent: "center",
        marginTop: 20,
    },
    text: { fontSize: 14, color: "#333" },
    linkText: { fontSize: 14, color: "#1d4ed8", fontWeight: "500" },
});