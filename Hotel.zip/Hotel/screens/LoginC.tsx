import React, { useState } from "react";
import {
    View,
    Text,
    TextInput,
    TouchableOpacity,
    Image,
    StyleSheet,
    ScrollView,
    KeyboardAvoidingView,
    Platform,
    SafeAreaView,
    Alert
} from "react-native";
import { useNavigation } from "@react-navigation/native";
import { useAuth } from '../AuthContext';

type LoginProps = {
    onLoginSuccess?: (email: string) => void;
};

export default function Login({ onLoginSuccess }: LoginProps) {
    const [email, setEmail] = useState<string>("");
    const [password, setPassword] = useState<string>("");
    const [showPassword, setShowPassword] = useState<boolean>(false);
    const [error, setError] = useState<string>("");

    const navigation = useNavigation<any>();
    const { login } = useAuth();
    const handleLogin = () => {
        const result = login(email, password);

        if (result.success) {
            setError("");
            Alert.alert("¡Éxito!", `Bienvenido ${result.user.name}`);
            navigation.navigate("Home");
        } else {
            setError(result.error);
        }
    };

    /*
    const handleLogin = () => {
        if (email === "admin@example.com" && password === "1234") {
            onLoginSuccess?.(email);
            navigation.navigate("AdminDashboard");
        } else {
            setError("Correo o contraseña incorrectos");
        }
    };
*/
    return (
        <SafeAreaView style={styles.safeArea}>
            <KeyboardAvoidingView
                behavior={Platform.OS === "ios" ? "padding" : "height"}
                style={styles.keyboardAvoid}
            >
                <ScrollView
                    contentContainerStyle={styles.scrollContainer}
                    keyboardShouldPersistTaps="handled"
                >
                    <View style={styles.container}>
                        {/* Header */}
                        <View style={styles.header}>
                            <View style={styles.logoCircle}>
                                <Image source={require('./../assets/logo.jpg')} style={styles.logoImg} />
                            </View>
                            <Text style={styles.title}>Bienvenido</Text>
                            <Text style={styles.subtitle}>Por favor, inicia sesión.</Text>
                        </View>

                        {/* Formulario */}
                        <View style={styles.form}>
                            <Text style={styles.label}>Correo electrónico</Text>
                            <TextInput
                                style={styles.input}
                                placeholder="tu@email.com"
                                value={email}
                                onChangeText={setEmail}
                                keyboardType="email-address"
                                autoCapitalize="none"
                            />

                            <Text style={styles.label}>Contraseña</Text>
                            <View style={styles.passwordContainer}>
                                <TextInput
                                    style={styles.inputPassword}
                                    placeholder="********"
                                    secureTextEntry={!showPassword}
                                    value={password}
                                    onChangeText={setPassword}
                                />
                                <TouchableOpacity
                                    style={styles.eyeIconContainer}
                                    onPress={() => setShowPassword(!showPassword)}
                                >
                                    <Image
                                        source={showPassword ? require('./../assets/eye-open.png') : require('./../assets/eye-closed.png')}
                                        style={styles.eyeIcon}
                                    />
                                </TouchableOpacity>
                            </View>

                            {error ? <Text style={styles.error}>{error}</Text> : null}

                            <TouchableOpacity
                                onPress={() => navigation.navigate("ForgotPassword")}
                                style={styles.linkRight}
                            >
                                <Text style={styles.linkText}>¿Olvidaste tu contraseña?</Text>
                            </TouchableOpacity>

                            <TouchableOpacity style={styles.loginButton} onPress={handleLogin}>
                                <Text style={styles.loginButtonText}>Iniciar sesión</Text>
                            </TouchableOpacity>

                            <View style={styles.registerOption}>
                                <Text style={styles.text}>¿No tienes una cuenta? </Text>
                                <TouchableOpacity onPress={() => navigation.navigate("Registrate")}>
                                    <Text style={styles.linkText}>Crear cuenta</Text>
                                </TouchableOpacity>
                            </View>
                        </View>
                    </View>
                </ScrollView>
            </KeyboardAvoidingView>
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    safeArea: {
        flex: 1,
        backgroundColor: "#eef3ff",
    },
    keyboardAvoid: {
        flex: 1,
    },
    scrollContainer: {
        flexGrow: 1,
        justifyContent: "center",
    },
    container: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
        paddingHorizontal: 20,
        paddingVertical: 20,
    },
    header: { alignItems: "center", marginBottom: 20 },
    logoCircle: {
        justifyContent: "center",
        alignItems: "center",
        backgroundColor: "#002a7f",
        width: 70,
        height: 70,
        borderRadius: 35,
        marginBottom: 10,
    },
    logoImg: { width: 50, height: 50, resizeMode: "contain" },
    title: { fontSize: 24, fontWeight: "bold", color: "#060e3a" },
    subtitle: { fontSize: 16, color: "#3d4046" },
    form: {
        backgroundColor: "white",
        padding: 25,
        borderRadius: 15,
        width: "100%",
        maxWidth: 350,
        shadowColor: "#000",
        shadowOpacity: 0.1,
        shadowRadius: 10,
        elevation: 3,
    },
    label: { fontSize: 16, fontWeight: "600", color: "#060e3a", marginTop: 10 },
    input: {
        borderWidth: 1,
        borderColor: "#cbd5e1",
        borderRadius: 10,
        padding: 10,
        marginTop: 5,
        marginBottom: 10,
        height: 45,
    },
    passwordContainer: {
        flexDirection: "row",
        alignItems: "center",
        borderWidth: 1,
        borderColor: "#cbd5e1",
        borderRadius: 10,
        marginBottom: 15,
    },
    inputPassword: { flex: 1, padding: 10, height: 45 },
    eyeIconContainer: { paddingHorizontal: 10 },
    eyeIcon: { width: 22, height: 22, tintColor: "#333" },
    error: { color: "red", fontSize: 13, marginBottom: 10 },
    linkRight: { alignItems: "flex-end", marginBottom: 15 },
    linkText: { fontSize: 14, color: "#1d4ed8", fontWeight: "500" },
    loginButton: {
        backgroundColor: "#002a7f",
        padding: 12,
        borderRadius: 12,
        alignItems: "center",
        marginTop: 10,
    },
    loginButtonText: { color: "white", fontWeight: "bold", fontSize: 15 },
    registerOption: {
        flexDirection: "row",
        justifyContent: "center",
        marginTop: 20,
    },
    text: { fontSize: 14, color: "#333" },
});