import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { useAuth } from '../AuthContext';
import { useNavigation } from '@react-navigation/native';

export default function DashboardScreen() {
    const { user, logout } = useAuth();
    const navigation = useNavigation();

    return (
        <ScrollView style={styles.container}>
            <View style={styles.header}>
                <Text style={styles.title}>Mi Cuenta</Text>
                <Text style={styles.subtitle}>Bienvenido, {user?.name}</Text>
            </View>

            <View style={styles.section}>
                <Text style={styles.sectionTitle}>Mis Reservas</Text>
                <TouchableOpacity
                    style={styles.card}
                    onPress={() => navigation.navigate('Reservar')}
                >
                    <Text style={styles.cardText}>Ver mis reservas activas</Text>
                </TouchableOpacity>
            </View>

            <View style={styles.section}>
                <Text style={styles.sectionTitle}>Mis Datos</Text>
                <View style={styles.infoCard}>
                    <Text style={styles.infoLabel}>Nombre:</Text>
                    <Text style={styles.infoValue}>{user?.name}</Text>
                </View>
                <View style={styles.infoCard}>
                    <Text style={styles.infoLabel}>Email:</Text>
                    <Text style={styles.infoValue}>{user?.email}</Text>
                </View>
            </View>

            <TouchableOpacity
                style={styles.logoutButton}
                onPress={() => {
                    logout();
                    navigation.navigate('Home');
                }}
            >
                <Text style={styles.logoutButtonText}>Cerrar Sesión</Text>
            </TouchableOpacity>
        </ScrollView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#f5f5f5',
        padding: 20,
    },
    header: {
        marginBottom: 30,
    },
    title: {
        fontSize: 28,
        fontWeight: 'bold',
        color: '#333',
    },
    subtitle: {
        fontSize: 18,
        color: '#666',
        marginTop: 5,
    },
    section: {
        marginBottom: 25,
    },
    sectionTitle: {
        fontSize: 20,
        fontWeight: '600',
        color: '#333',
        marginBottom: 15,
    },
    card: {
        backgroundColor: 'white',
        padding: 20,
        borderRadius: 10,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
        elevation: 3,
    },
    cardText: {
        fontSize: 16,
        color: '#4267B2',
    },
    infoCard: {
        backgroundColor: 'white',
        padding: 15,
        borderRadius: 8,
        marginBottom: 10,
        flexDirection: 'row',
        justifyContent: 'space-between',
    },
    infoLabel: {
        fontSize: 16,
        fontWeight: '600',
        color: '#333',
    },
    infoValue: {
        fontSize: 16,
        color: '#666',
    },
    logoutButton: {
        backgroundColor: '#ff4757',
        padding: 15,
        borderRadius: 8,
        alignItems: 'center',
        marginTop: 20,
    },
    logoutButtonText: {
        color: 'white',
        fontSize: 16,
        fontWeight: 'bold',
    },
});