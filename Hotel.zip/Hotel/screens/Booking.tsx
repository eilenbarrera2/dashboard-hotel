import React, { useMemo, useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';

// ---- Tipos ----
type RoomType =
    | 'No disponible'
    | 'Sencilla'
    | 'Doble'
    | 'Triple'
    | 'Familiar'
    | 'Familiar con Jacuzzi';

interface Room {
    id: string;
    type: RoomType;
    color: string;
}

// ---- Datos ----
const floors: Record<number, Room[]> = {
    1: [
        { id: '101', type: 'Sencilla', color: '#e74c3c' },
        { id: '102', type: 'No disponible', color: '#95a5a6' },
        { id: '103', type: 'Familiar', color: '#a0522d' },
        { id: '104', type: 'Familiar con Jacuzzi', color: '#ff9999' },
        { id: '105', type: 'Triple', color: '#e67e22' },
        { id: '106', type: 'No disponible', color: '#95a5a6' },
        { id: '107', type: 'Doble', color: '#ff6347' },
    ],
    2: [
        { id: '201', type: 'Triple', color: '#e67e22' },
        { id: '202', type: 'Sencilla', color: '#e74c3c' },
        { id: '203', type: 'No disponible', color: '#95a5a6' },
        { id: '204', type: 'Doble', color: '#ff6347' },
        { id: '205', type: 'Familiar', color: '#a0522d' },
        { id: '206', type: 'No disponible', color: '#95a5a6' },
        { id: '207', type: 'Familiar con Jacuzzi', color: '#ff9999' },
    ],
    3: [
        { id: '301', type: 'No disponible', color: '#95a5a6' },
        { id: '302', type: 'Sencilla', color: '#e74c3c' },
        { id: '303', type: 'Triple', color: '#e67e22' },
        { id: '304', type: 'Doble', color: '#ff6347' },
        { id: '305', type: 'Familiar', color: '#a0522d' },
        { id: '306', type: 'Familiar con Jacuzzi', color: '#ff9999' },
        { id: '307', type: 'Sencilla', color: '#e74c3c' },
    ],
};

const legend: { label: RoomType; color: string }[] = [
    { label: 'No disponible', color: '#95a5a6' },
    { label: 'Sencilla', color: '#e74c3c' },
    { label: 'Doble', color: '#ff6347' },
    { label: 'Triple', color: '#e67e22' },
    { label: 'Familiar', color: '#a0522d' },
    { label: 'Familiar con Jacuzzi', color: '#ff9999' },
];

// ---- Componente ----
export default function BookingScreen(): JSX.Element {
    const [selectedFloor, setSelectedFloor] = useState<number>(1);
    const [selectedRooms, setSelectedRooms] = useState<string[]>([]);
    const [filter, setFilter] = useState<RoomType | null>(null);

    const roomsOnFloor = floors[selectedFloor];

    const filteredRooms: Room[] = useMemo(
        () => (filter ? roomsOnFloor.filter(r => r.type === filter) : roomsOnFloor),
        [roomsOnFloor, filter]
    );

    const toggleRoom = (room: Room) => {
        if (room.type === 'No disponible') return;
        setSelectedRooms(prev =>
            prev.includes(room.id)
                ? prev.filter(id => id !== room.id)
                : [...prev, room.id]
        );
    };

    return (
        <ScrollView style={styles.container} contentContainerStyle={styles.content}>
            <Text style={styles.mainTitle}>Habitaciones</Text>
            <Text style={styles.subtitle}>Elige tus habitaciones</Text>

            {/* Tabs de pisos */}
            <View style={styles.floorTabs}>
                {[1, 2, 3].map(floor => (
                    <TouchableOpacity
                        key={floor}
                        style={[
                            styles.floorButton,
                            selectedFloor === floor && styles.floorButtonActive,
                        ]}
                        onPress={() => setSelectedFloor(floor)}
                    >
                        <Text
                            style={[
                                styles.floorButtonText,
                                selectedFloor === floor && styles.floorButtonTextActive,
                            ]}
                        >
                            Piso {floor}
                        </Text>
                    </TouchableOpacity>
                ))}
            </View>

            {/* Grid de habitaciones */}
            <View style={styles.grid}>
                {filteredRooms.map(room => {
                    const isSelected = selectedRooms.includes(room.id);
                    const disabled = room.type === 'No disponible';
                    return (
                        <TouchableOpacity
                            key={room.id}
                            style={[
                                styles.roomButton,
                                { backgroundColor: room.color },
                                isSelected && styles.roomSelected,
                                disabled && styles.roomDisabled,
                            ]}
                            onPress={() => toggleRoom(room)}
                            disabled={disabled}
                        >
                            <Text style={styles.roomText}>{room.id}</Text>
                        </TouchableOpacity>
                    );
                })}
            </View>

            {/* Leyenda filtrable */}
            <Text style={styles.sectionTitle}>Leyenda</Text>
            <View style={styles.legend}>
                {legend.map(item => (
                    <TouchableOpacity
                        key={item.label}
                        onPress={() => setFilter(filter === item.label ? null : item.label)}
                        style={[
                            styles.legendItem,
                            filter === item.label && styles.legendActive,
                        ]}
                    >
                        <View style={[styles.legendColor, { backgroundColor: item.color }]} />
                        <Text style={styles.legendText}>{item.label}</Text>
                    </TouchableOpacity>
                ))}
            </View>

            {/* Botón reservar */}
            <TouchableOpacity style={styles.reserveButton}>
                <Text style={styles.reserveButtonText}>
                    Apartar habitaciones ({selectedRooms.length})
                </Text>
            </TouchableOpacity>
        </ScrollView>
    );
}

// ---- Estilos ----
const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: '#f8f9fa' },
    content: { padding: 20 },

    mainTitle: {
        fontSize: 28,
        fontWeight: 'bold',
        color: '#2c3e50',
        textAlign: 'center',
    },
    subtitle: {
        fontSize: 18,
        color: '#7f8c8d',
        marginBottom: 20,
        textAlign: 'center',
    },

    // Pisos
    floorTabs: {
        flexDirection: 'row',
        justifyContent: 'center',
        marginBottom: 15,
    },
    floorButton: {
        paddingVertical: 10,
        paddingHorizontal: 15,
        marginHorizontal: 6,
        borderRadius: 6,
        backgroundColor: '#ecf0f1',
    },
    floorButtonActive: { backgroundColor: '#3498db' },
    floorButtonText: { color: '#34495e', fontWeight: 'bold' },
    floorButtonTextActive: { color: '#fff' },

    // Habitaciones
    grid: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        justifyContent: 'center',
        marginBottom: 24,
    },
    roomButton: {
        width: 80,
        height: 60,
        margin: 6,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 10,
        elevation: 3,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.2,
        shadowRadius: 3,
    },
    roomText: { color: 'white', fontWeight: 'bold', fontSize: 14 },
    roomSelected: { borderWidth: 3, borderColor: '#2980b9' },
    roomDisabled: { opacity: 0.5 },

    // Leyenda
    sectionTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#34495e',
        marginBottom: 10,
    },
    legend: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        marginBottom: 25,
    },
    legendItem: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#ecf0f1',
        paddingVertical: 6,
        paddingHorizontal: 8,
        borderRadius: 6,
        marginRight: 10,
        marginBottom: 10,
    },
    legendActive: { backgroundColor: '#d6eaf8' },
    legendColor: { width: 18, height: 18, borderRadius: 4, marginRight: 6 },
    legendText: { fontSize: 14 },

    // Botón de reservar
    reserveButton: {
        backgroundColor: '#9b59b6',
        padding: 15,
        borderRadius: 8,
        alignItems: 'center',
    },
    reserveButtonText: { color: 'white', fontWeight: 'bold', fontSize: 18 },
});
