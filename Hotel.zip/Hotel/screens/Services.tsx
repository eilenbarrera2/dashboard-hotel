import React from 'react';
import { View, Text } from 'react-native';

const ServicesScreen = () => {
    return (
        <View>
            <Text>Nuestros Servicios</Text>
            {/* Agrega aquí tu contenido */}
        </View>
    );
};

export default ServicesScreen; // ¡Esta línea es crucial!