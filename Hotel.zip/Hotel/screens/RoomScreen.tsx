import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Image, Dimensions } from 'react-native';

const RoomTypesScreen = () => {
    const roomTypes = [
        {
            id: '1', // Añade un ID único para cada habitación
            title: "Habitación Sencilla",
            features: ["Cama individual", "Wi-Fi gratuito", "TV 32\""],
            image: require('./../assets/sencilla.jpg')
        },
        // ... resto de habitaciones con sus respectivos IDs
    ];

    return (
        <View style={styles.container}>
            <Text style={styles.header}>TIPOS DE HABITACIONES</Text>

            <ScrollView
                contentContainerStyle={styles.scrollContent}
                showsVerticalScrollIndicator={false}
            >
                {roomTypes.map((room) => (
                    <View key={`room-${room.id}`} style={styles.card}> {/* Key aquí en el contenedor */}
                        <Image
                            source={room.image}
                            style={styles.image}
                            resizeMode="cover"
                        />
                        <View style={styles.textContainer}>
                            <Text style={styles.title}>{room.title}</Text>

                            <View style={styles.features}>
                                {room.features.map((feature, featureIndex) => (
                                    <Text
                                        key={`feature-${room.id}-${featureIndex}`} // Key única para cada feature
                                        style={styles.feature}
                                    >
                                        • {feature}
                                    </Text>
                                ))}
                            </View>

                            <TouchableOpacity style={styles.button}>
                                <Text style={styles.buttonText}>Más información</Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                ))}
            </ScrollView>
        </View>
    );
};

// ... (tus estilos se mantienen igual)

const { width } = Dimensions.get('window');
const CARD_WIDTH = width - 40;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#f5f5f5',
        paddingTop: 15,
    },
    scrollContent: {
        paddingBottom: 20,
        paddingTop: 10,
    },
    header: {
        fontSize: 22,
        fontWeight: 'bold',
        color: '#2c3e50',
        textAlign: 'center',
        marginBottom: 20,
        paddingHorizontal: 10,
    },
    card: {
        backgroundColor: 'white',
        borderRadius: 10,
        marginHorizontal: 20,
        marginBottom: 15,
        elevation: 3,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
        width: CARD_WIDTH,
        alignSelf: 'center',
    },
    cardContent: {
        flexDirection: 'row',
        height: 140,
    },
    image: {
        width: '35%',
        height: '100%',
        borderTopLeftRadius: 10,
        borderBottomLeftRadius: 10,
    },
    textContainer: {
        flex: 1,
        padding: 12,
        justifyContent: 'space-between',
    },
    title: {
        fontSize: 17,
        fontWeight: '600',
        color: '#2c3e50',
        marginBottom: 8,
    },
    features: {
        marginBottom: 10,
    },
    feature: {
        fontSize: 14,
        color: '#555',
        marginBottom: 4,
        lineHeight: 20,
    },
    button: {
        backgroundColor: '#3498db',
        paddingVertical: 8,
        borderRadius: 5,
        alignItems: 'center',
        marginTop: 5,
    },
    buttonText: {
        color: 'white',
        fontSize: 14,
        fontWeight: '500',
    },
});

export default RoomTypesScreen;