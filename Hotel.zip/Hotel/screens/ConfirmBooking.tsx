import React, { useState } from "react";
import {
    View,
    Text,
    TouchableOpacity,
    StyleSheet,
    Alert,
    ScrollView,
    KeyboardAvoidingView,
    Platform
} from "react-native";
import { Calendar, LocaleConfig } from "react-native-calendars";
import { RouteProp, useRoute } from "@react-navigation/native";
import { Ionicons } from "@expo/vector-icons";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { useNavigation } from "@react-navigation/native";

// ✅ Configuración de idioma en español para el calendario
LocaleConfig.locales["es"] = {
    monthNames: [
        "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
        "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"
    ],
    monthNamesShort: [
        "Ene.", "Feb.", "Mar.", "Abr.", "May.", "Jun.",
        "Jul.", "Ago.", "Sep.", "Oct.", "Nov.", "Dic."
    ],
    dayNames: [
        "Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"
    ],
    dayNamesShort: ["Dom.", "Lun.", "Mar.", "Mié.", "Jue.", "Vie.", "Sáb."],
    today: "Hoy"
};
LocaleConfig.defaultLocale = "es";

type RootStackParamList = {
    ConfirmBooking: { selectedRooms: string[] };
    PaymentScreen: {
        selectedRooms: string[];
        checkIn: string;
        checkOut: string;
        adults: number;
        children: number;
    };
};

type ReservationDetailsScreenRouteProp = RouteProp<RootStackParamList, "ConfirmBooking">;

export default function ReservationDetailsScreen() {
    const route = useRoute<ReservationDetailsScreenRouteProp>();
    const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
    const { selectedRooms } = route.params;

    const [checkIn, setCheckIn] = useState<string | null>(null);
    const [checkOut, setCheckOut] = useState<string | null>(null);
    const [markedDates, setMarkedDates] = useState({});
    const [adults, setAdults] = useState(1);
    const [children, setChildren] = useState(0);

    // ✅ Genera rango con formato "period"
    const generateRange = (start: string, end: string) => {
        let range: any = {};
        let startDate = new Date(start);
        let endDate = new Date(end);

        while (startDate <= endDate) {
            let dateString = startDate.toISOString().split("T")[0];
            range[dateString] = {
                color: "#70d7c7",
                textColor: "white",
            };
            startDate.setDate(startDate.getDate() + 1);
        }

        // Marcar inicio y fin con estilo especial
        range[start] = { startingDay: true, color: "#4A90E2", textColor: "white" };
        range[end] = { endingDay: true, color: "#4A90E2", textColor: "white" };

        return range;
    };

    // ✅ Manejo de selección de fechas
    const handleDayPress = (day: any) => {
        if (!checkIn) {
            setCheckIn(day.dateString);
            setCheckOut(null);
            setMarkedDates({
                [day.dateString]: { startingDay: true, color: "#4A90E2", textColor: "white" },
            });
        } else if (checkIn && !checkOut) {
            if (day.dateString < checkIn) {
                // Reinicia si la nueva fecha es anterior
                setCheckIn(day.dateString);
                setCheckOut(null);
                setMarkedDates({
                    [day.dateString]: { startingDay: true, color: "#4A90E2", textColor: "white" },
                });
            } else {
                setCheckOut(day.dateString);
                setMarkedDates(generateRange(checkIn, day.dateString));
            }
        } else {
            // Reinicia si ya había rango
            setCheckIn(day.dateString);
            setCheckOut(null);
            setMarkedDates({
                [day.dateString]: { startingDay: true, color: "#4A90E2", textColor: "white" },
            });
        }
    };

    // ✅ Confirmar y navegar
    const handleConfirm = () => {
        if (!checkIn || !checkOut) {
            Alert.alert("Error", "Por favor selecciona fechas de entrada y salida.");
            return;
        }

        if (new Date(checkOut) <= new Date(checkIn)) {
            Alert.alert("Error", "La fecha de salida debe ser posterior a la de entrada.");
            return;
        }

        navigation.navigate("PaymentScreen", {
            selectedRooms,
            checkIn,
            checkOut,
            adults,
            children
        });
    };

    // ✅ Contadores de huéspedes
    const incrementAdults = () => setAdults(prev => prev + 1);
    const decrementAdults = () => adults > 1 && setAdults(prev => prev - 1);
    const incrementChildren = () => setChildren(prev => prev + 1);
    const decrementChildren = () => children > 0 && setChildren(prev => prev - 1);

    return (
        <KeyboardAvoidingView
            style={styles.container}
            behavior={Platform.OS === "ios" ? "padding" : "height"}
            keyboardVerticalOffset={Platform.OS === "ios" ? 90 : 0}
        >
            <ScrollView
                style={styles.scrollView}
                showsVerticalScrollIndicator={false}
                contentContainerStyle={styles.scrollContent}
            >
                {/* Header */}
                <View style={styles.header}>
                    <Text style={styles.title}>Detalles de tu reserva</Text>
                    <View style={styles.roomsContainer}>
                        <Text style={styles.subtitle}>Habitaciones seleccionadas:</Text>
                        <View style={styles.roomsList}>
                            {selectedRooms.length > 0 ? (
                                selectedRooms.map((room, index) => (
                                    <View key={index} style={styles.roomChip}>
                                        <Text style={styles.roomText}>{room}</Text>
                                    </View>
                                ))
                            ) : (
                                <Text style={styles.noRoomsText}>No hay habitaciones seleccionadas</Text>
                            )}
                        </View>
                    </View>
                </View>

                {/* Calendario */}
                <View style={styles.section}>
                    <Text style={styles.sectionTitle}>Selecciona tus fechas</Text>
                    <View style={styles.calendarContainer}>
                        <Calendar
                            markingType="period"
                            markedDates={markedDates}
                            onDayPress={handleDayPress}
                            firstDay={1}
                            monthFormat={"MMMM yyyy"}
                            hideExtraDays={true}
                        />
                    </View>

                    <View style={styles.dateSummary}>
                        <View style={styles.dateItem}>
                            <Text style={styles.dateLabel}>Check-in</Text>
                            <Text style={styles.dateValue}>{checkIn || "--/--/----"}</Text>
                        </View>
                        <View style={styles.dateSeparator} />
                        <View style={styles.dateItem}>
                            <Text style={styles.dateLabel}>Check-out</Text>
                            <Text style={styles.dateValue}>{checkOut || "--/--/----"}</Text>
                        </View>
                    </View>
                </View>

                {/* Huéspedes */}
                <View style={styles.section}>
                    <Text style={styles.sectionTitle}>Huéspedes</Text>

                    <View style={styles.guestInputContainer}>
                        <View style={styles.guestInput}>
                            <View>
                                <Text style={styles.guestLabel}>Adultos</Text>
                                <Text style={styles.guestSubLabel}>Mayores de 12 años</Text>
                            </View>
                            <View style={styles.counterContainer}>
                                <TouchableOpacity
                                    style={[styles.counterButton, adults <= 1 && styles.counterButtonDisabled]}
                                    onPress={decrementAdults}
                                    disabled={adults <= 1}
                                >
                                    <Ionicons name="remove" size={20} color={adults <= 1 ? "#CCC" : "#4A90E2"} />
                                </TouchableOpacity>
                                <Text style={styles.counterValue}>{adults}</Text>
                                <TouchableOpacity style={styles.counterButton} onPress={incrementAdults}>
                                    <Ionicons name="add" size={20} color="#4A90E2" />
                                </TouchableOpacity>
                            </View>
                        </View>

                        <View style={styles.separator} />

                        <View style={styles.guestInput}>
                            <View>
                                <Text style={styles.guestLabel}>Niños</Text>
                                <Text style={styles.guestSubLabel}>Menores de 12 años</Text>
                            </View>
                            <View style={styles.counterContainer}>
                                <TouchableOpacity
                                    style={[styles.counterButton, children <= 0 && styles.counterButtonDisabled]}
                                    onPress={decrementChildren}
                                    disabled={children <= 0}
                                >
                                    <Ionicons name="remove" size={20} color={children <= 0 ? "#CCC" : "#4A90E2"} />
                                </TouchableOpacity>
                                <Text style={styles.counterValue}>{children}</Text>
                                <TouchableOpacity style={styles.counterButton} onPress={incrementChildren}>
                                    <Ionicons name="add" size={20} color="#4A90E2" />
                                </TouchableOpacity>
                            </View>
                        </View>
                    </View>
                </View>

                {/* Botón Confirmar */}
                <TouchableOpacity
                    style={[styles.confirmButton, (!checkIn || !checkOut) && styles.confirmButtonDisabled]}
                    onPress={handleConfirm}
                    disabled={!checkIn || !checkOut}
                >
                    <Text style={styles.confirmText}>Confirmar Reserva</Text>
                </TouchableOpacity>
            </ScrollView>
        </KeyboardAvoidingView>
    );
}

// ✅ Estilos
const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: "#F8F9FA" },
    scrollView: { flex: 1 },
    scrollContent: { padding: 20, paddingBottom: 40 },
    header: { marginBottom: 24 },
    title: { fontSize: 28, fontWeight: "bold", color: "#2c3e50", marginBottom: 16 },
    subtitle: { fontSize: 16, color: "#7f8c8d", marginBottom: 8 },
    roomsContainer: { marginBottom: 8 },
    roomsList: { flexDirection: "row", flexWrap: "wrap", marginTop: 8 },
    roomChip: {
        backgroundColor: "#E8F4FF",
        paddingHorizontal: 12,
        paddingVertical: 6,
        borderRadius: 16,
        marginRight: 8,
        marginBottom: 8,
    },
    roomText: { color: "#4A90E2", fontWeight: "500" },
    noRoomsText: { color: "#95a5a6", fontStyle: "italic" },
    section: {
        backgroundColor: "white",
        borderRadius: 16,
        padding: 20,
        marginBottom: 24,
        shadowColor: "#000",
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 3.84,
        elevation: 5,
    },
    sectionTitle: { fontSize: 18, fontWeight: "bold", color: "#2c3e50", marginBottom: 16 },
    calendarContainer: { borderRadius: 12, overflow: "hidden", marginBottom: 16 },
    dateSummary: {
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        backgroundColor: "#F8F9FA",
        borderRadius: 12,
        padding: 16,
    },
    dateItem: { alignItems: "center", flex: 1 },
    dateLabel: { fontSize: 14, color: "#7f8c8d", marginBottom: 4 },
    dateValue: { fontSize: 16, fontWeight: "600", color: "#2c3e50" },
    dateSeparator: { width: 1, height: 40, backgroundColor: "#DDD" },
    guestInputContainer: { backgroundColor: "#F8F9FA", borderRadius: 12, overflow: "hidden" },
    guestInput: {
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        padding: 16,
    },
    guestLabel: { fontSize: 16, fontWeight: "600", color: "#2c3e50", marginBottom: 4 },
    guestSubLabel: { fontSize: 14, color: "#7f8c8d" },
    counterContainer: { flexDirection: "row", alignItems: "center" },
    counterButton: {
        width: 40,
        height: 40,
        borderRadius: 20,
        borderWidth: 1,
        borderColor: "#4A90E2",
        justifyContent: "center",
        alignItems: "center",
        backgroundColor: "white",
    },
    counterButtonDisabled: { borderColor: "#ECF0F1", backgroundColor: "#F8F9FA" },
    counterValue: { fontSize: 18, fontWeight: "600", marginHorizontal: 16, minWidth: 24, textAlign: "center", color: "#2c3e50" },
    separator: { height: 1, backgroundColor: "#ECF0F1" },
    confirmButton: {
        backgroundColor: "#27ae60",
        padding: 18,
        borderRadius: 12,
        alignItems: "center",
        marginTop: 8,
        shadowColor: "#27ae60",
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.3,
        shadowRadius: 4.65,
        elevation: 8,
    },
    confirmButtonDisabled: { backgroundColor: "#bdc3c7" },
    confirmText: { color: "white", fontSize: 18, fontWeight: "bold" },
});
