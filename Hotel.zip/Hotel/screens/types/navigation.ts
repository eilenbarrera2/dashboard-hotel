export type RootStackParamList = {
    Home: undefined;
    Habitaciones: undefined;
    Servicios: undefined;
    Reservar: undefined;
    Login: undefined;
    Register: undefined;
    ConfirmBooking: { selectedRooms: string[] };
    PaymentScreen: {
        selectedRooms: string[];
        checkIn: string;
        checkOut: string;
        adults: number;
        children: number;
    };
    Dashboard: undefined;
};

declare global {
    namespace ReactNavigation {
        interface RootParamList extends RootStackParamList { }
    }
}