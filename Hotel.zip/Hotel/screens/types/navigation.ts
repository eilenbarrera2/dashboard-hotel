export type RootStackParamList = {
    Home: undefined;
    Habitaciones: undefined;
    Servicios: undefined;
    Reservar: undefined;
    Login: undefined;
    Register: undefined;
};

declare global {
    namespace ReactNavigation {
        interface RootParamList extends RootStackParamList { }
    }
}