import React, { useState } from "react";
import {
    View,
    Text,
    TextInput,
    TouchableOpacity,
    StyleSheet,
    ScrollView,
    Alert,
    KeyboardAvoidingView,
    Platform
} from "react-native";
import { RouteProp, useRoute } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { useNavigation } from "@react-navigation/native";
import { Ionicons } from "@expo/vector-icons";

type RootStackParamList = {
    ConfirmBooking: { selectedRooms: string[] };
    Payment: {
        selectedRooms: string[];
        checkIn: string;
        checkOut: string;
        adults: number;
        children: number;
    };
};

type PaymentScreenRouteProp = RouteProp<RootStackParamList, "Payment">;

export default function PaymentScreen() {
    const route = useRoute<PaymentScreenRouteProp>();
    const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();

    const {
        selectedRooms,
        checkIn,
        checkOut,
        adults,
        children
    } = route.params;

    // Estados para los datos de la tarjeta
    const [cardNumber, setCardNumber] = useState("");
    const [cardHolder, setCardHolder] = useState("");
    const [expiryDate, setExpiryDate] = useState("");
    const [cvv, setCvv] = useState("");
    const [isProcessing, setIsProcessing] = useState(false);

    const handlePayment = () => {
        // Validaciones básicas
        if (!cardNumber || !cardHolder || !expiryDate || !cvv) {
            Alert.alert("Error", "Por favor completa todos los campos de la tarjeta");
            return;
        }

        if (cardNumber.replace(/\s/g, '').length !== 16) {
            Alert.alert("Error", "El número de tarjeta debe tener 16 dígitos");
            return;
        }

        if (cvv.length !== 3) {
            Alert.alert("Error", "El CVV debe tener 3 dígitos");
            return;
        }

        setIsProcessing(true);

        // Simular procesamiento de pago
        setTimeout(() => {
            setIsProcessing(false);
            Alert.alert(
                "Pago Exitoso",
                "¡Tu reserva ha sido confirmada y el pago procesado correctamente!",
                [
                    {
                        text: "OK",
                        // onPress: () => navigation.navigate("DashboardCustom") // O la pantalla que corresponda
                    }
                ]
            );
        }, 2000);
    };

    // Calcular el total (ejemplo básico)
    const roomPrice = 150; // Precio por noche por habitación
    const nights = Math.ceil(
        (new Date(checkOut).getTime() - new Date(checkIn).getTime()) / (1000 * 3600 * 24)
    );
    const total = selectedRooms.length * roomPrice * nights;

    return (
        <KeyboardAvoidingView
            style={styles.container}
            behavior={Platform.OS === "ios" ? "padding" : "height"}
            keyboardVerticalOffset={Platform.OS === "ios" ? 90 : 0}
        >
            <ScrollView style={styles.scrollView}>
                <View style={styles.header}>
                    <Text style={styles.title}>Resumen de Reservación</Text>
                </View>

                {/* Resumen de la reserva */}
                <View style={styles.section}>
                    <Text style={styles.sectionTitle}>Detalles de la Reserva</Text>

                    <View style={styles.detailRow}>
                        <Text style={styles.detailLabel}>Habitaciones:</Text>
                        <Text style={styles.detailValue}>{selectedRooms.join(", ")}</Text>
                    </View>

                    <View style={styles.detailRow}>
                        <Text style={styles.detailLabel}>Check-in:</Text>
                        <Text style={styles.detailValue}>{checkIn}</Text>
                    </View>

                    <View style={styles.detailRow}>
                        <Text style={styles.detailLabel}>Check-out:</Text>
                        <Text style={styles.detailValue}>{checkOut}</Text>
                    </View>

                    <View style={styles.detailRow}>
                        <Text style={styles.detailLabel}>Huéspedes:</Text>
                        <Text style={styles.detailValue}>{adults} adultos, {children} niños</Text>
                    </View>

                    <View style={styles.detailRow}>
                        <Text style={styles.detailLabel}>Noches:</Text>
                        <Text style={styles.detailValue}>{nights}</Text>
                    </View>

                    <View style={[styles.detailRow, styles.totalRow]}>
                        <Text style={styles.totalLabel}>Total:</Text>
                        <Text style={styles.totalValue}>${total}</Text>
                    </View>
                </View>

                {/* Formulario de pago */}
                <View style={styles.section}>
                    <Text style={styles.sectionTitle}>Información de Pago</Text>

                    <View style={styles.inputContainer}>
                        <Text style={styles.inputLabel}>Titular de la Tarjeta</Text>
                        <TextInput
                            style={styles.input}
                            value={cardHolder}
                            onChangeText={setCardHolder}
                            placeholder="Nombre como aparece en la tarjeta"
                        />
                    </View>

                    <View style={styles.inputContainer}>
                        <Text style={styles.inputLabel}>Número de Tarjeta</Text>
                        <TextInput
                            style={styles.input}
                            value={cardNumber}
                            onChangeText={setCardNumber}
                            placeholder="1234 5678 9012 3456"
                            keyboardType="numeric"
                            maxLength={19}
                        />
                    </View>

                    <View style={styles.row}>
                        <View style={[styles.inputContainer, styles.halfInput]}>
                            <Text style={styles.inputLabel}>Fecha de Expiración</Text>
                            <TextInput
                                style={styles.input}
                                value={expiryDate}
                                onChangeText={setExpiryDate}
                                placeholder="MM/AA"
                                maxLength={5}
                            />
                        </View>

                        <View style={[styles.inputContainer, styles.halfInput]}>
                            <Text style={styles.inputLabel}>CVV</Text>
                            <TextInput
                                style={styles.input}
                                value={cvv}
                                onChangeText={setCvv}
                                placeholder="123"
                                keyboardType="numeric"
                                maxLength={3}
                                secureTextEntry
                            />
                        </View>
                    </View>
                </View>

                {/* Botón de pago */}
                <TouchableOpacity
                    style={[styles.payButton, isProcessing && styles.payButtonDisabled]}
                    onPress={handlePayment}
                    disabled={isProcessing}
                >
                    {isProcessing ? (
                        <Text style={styles.payButtonText}>Procesando...</Text>
                    ) : (
                        <Text style={styles.payButtonText}>Pagar ${total}</Text>
                    )}
                </TouchableOpacity>
            </ScrollView>
        </KeyboardAvoidingView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "#F8F9FA",
    },
    scrollView: {
        flex: 1,
        padding: 20,
    },
    header: {
        marginBottom: 24,
    },
    title: {
        fontSize: 28,
        fontWeight: "bold",
        color: "#2c3e50",
        marginBottom: 16,
    },
    section: {
        backgroundColor: "white",
        borderRadius: 16,
        padding: 20,
        marginBottom: 24,
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.1,
        shadowRadius: 3.84,
        elevation: 5,
    },
    sectionTitle: {
        fontSize: 18,
        fontWeight: "bold",
        color: "#2c3e50",
        marginBottom: 16,
    },
    detailRow: {
        flexDirection: "row",
        justifyContent: "space-between",
        marginBottom: 12,
    },
    detailLabel: {
        fontSize: 16,
        color: "#7f8c8d",
    },
    detailValue: {
        fontSize: 16,
        fontWeight: "500",
        color: "#2c3e50",
    },
    totalRow: {
        borderTopWidth: 1,
        borderTopColor: "#ECF0F1",
        paddingTop: 12,
        marginTop: 8,
    },
    totalLabel: {
        fontSize: 18,
        fontWeight: "bold",
        color: "#2c3e50",
    },
    totalValue: {
        fontSize: 18,
        fontWeight: "bold",
        color: "#27ae60",
    },
    inputContainer: {
        marginBottom: 16,
    },
    inputLabel: {
        fontSize: 16,
        fontWeight: "600",
        color: "#2c3e50",
        marginBottom: 8,
    },
    input: {
        borderWidth: 1,
        borderColor: "#DDD",
        borderRadius: 8,
        padding: 12,
        fontSize: 16,
    },
    row: {
        flexDirection: "row",
        justifyContent: "space-between",
    },
    halfInput: {
        width: "48%",
    },
    payButton: {
        backgroundColor: "#27ae60",
        padding: 18,
        borderRadius: 12,
        alignItems: "center",
        marginTop: 8,
        marginBottom: 40,
    },
    payButtonDisabled: {
        backgroundColor: "#bdc3c7",
    },
    payButtonText: {
        color: "white",
        fontSize: 18,
        fontWeight: "bold",
    },
});