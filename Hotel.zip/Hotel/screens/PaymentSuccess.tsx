import React from "react";
import {
    View,
    Text,
    TouchableOpacity,
    StyleSheet,
    ScrollView,
    Alert
} from "react-native";
import { RouteProp, useRoute } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { useNavigation } from "@react-navigation/native";
import { Ionicons } from "@expo/vector-icons";

type RootStackParamList = {
    Payment: {
        selectedRooms: string[];
        checkIn: string;
        checkOut: string;
        adults: number;
        children: number;
    };
    PaymentSuccess: {
        selectedRooms: string[];
        checkIn: string;
        checkOut: string;
        adults: number;
        children: number;
        total: number;
        transactionId: string;
        cardLastDigits: string;
        customerEmail: string;
    };
    Home: undefined;
};

type PaymentSuccessScreenRouteProp = RouteProp<RootStackParamList, "PaymentSuccess">;

export default function PaymentSuccessScreen() {
    const route = useRoute<PaymentSuccessScreenRouteProp>();
    const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();

    const {
        selectedRooms,
        checkIn,
        checkOut,
        adults,
        children,
        total,
        transactionId,
        cardLastDigits,
        customerEmail
    } = route.params;

    // Calcular la cantidad de noches
    const nights = Math.ceil(
        (new Date(checkOut).getTime() - new Date(checkIn).getTime()) / (1000 * 3600 * 24)
    );

    const handleBackToDashboard = () => {
        // Navegar al dashboard principal
        navigation.navigate("Home");
    };

    return (
        <ScrollView style={styles.container} contentContainerStyle={styles.content}>
            {/* Icono de éxito */}
            <View style={styles.iconContainer}>
                <View style={styles.successCircle}>
                    <Ionicons name="checkmark" size={60} color="#FFF" />
                </View>
            </View>

            {/* Mensaje de confirmación */}
            <Text style={styles.successTitle}>¡Pago Realizado con Éxito!</Text>
            <Text style={styles.successMessage}>
                Hemos enviado un correo de confirmación a {customerEmail} con los detalles de tu reserva.
            </Text>

            {/* Detalles de la transacción */}
            <View style={styles.detailsCard}>
                <Text style={styles.detailsTitle}>Detalles de la Transacción</Text>

                <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>ID de Transacción:</Text>
                    <Text style={styles.detailValue}>{transactionId}</Text>
                </View>

                <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>Tarjeta:</Text>
                    <Text style={styles.detailValue}>•••• •••• •••• {cardLastDigits}</Text>
                </View>

                <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>Monto Total:</Text>
                    <Text style={styles.detailValue}>${total.toFixed(2)}</Text>
                </View>

                <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>Fecha:</Text>
                    <Text style={styles.detailValue}>{new Date().toLocaleDateString()}</Text>
                </View>
            </View>

            {/* Resumen de la reserva */}
            <View style={styles.detailsCard}>
                <Text style={styles.detailsTitle}>Resumen de tu Reserva</Text>

                <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>Habitaciones:</Text>
                    <Text style={styles.detailValue}>{selectedRooms.join(", ")}</Text>
                </View>

                <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>Check-in:</Text>
                    <Text style={styles.detailValue}>{checkIn}</Text>
                </View>

                <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>Check-out:</Text>
                    <Text style={styles.detailValue}>{checkOut}</Text>
                </View>

                <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>Noches:</Text>
                    <Text style={styles.detailValue}>{nights}</Text>
                </View>

                <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>Huéspedes:</Text>
                    <Text style={styles.detailValue}>{adults} adultos, {children} niños</Text>
                </View>

                <View style={[styles.detailRow, styles.totalRow]}>
                    <Text style={styles.totalLabel}>Total Pagado:</Text>
                    <Text style={styles.totalValue}>${total.toFixed(2)}</Text>
                </View>
            </View>

            {/* Botón para volver al dashboard */}
            <TouchableOpacity style={styles.dashboardButton} onPress={handleBackToDashboard}>
                <Text style={styles.dashboardButtonText}>Volver al Dashboard Principal</Text>
            </TouchableOpacity>
        </ScrollView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "#F8F9FA",
    },
    content: {
        padding: 20,
        paddingBottom: 40,
    },
    iconContainer: {
        alignItems: "center",
        marginVertical: 30,
    },
    successCircle: {
        width: 100,
        height: 100,
        borderRadius: 50,
        backgroundColor: "#27ae60",
        justifyContent: "center",
        alignItems: "center",
    },
    successTitle: {
        fontSize: 28,
        fontWeight: "bold",
        color: "#2c3e50",
        textAlign: "center",
        marginBottom: 10,
    },
    successMessage: {
        fontSize: 16,
        color: "#7f8c8d",
        textAlign: "center",
        marginBottom: 30,
        lineHeight: 22,
    },
    detailsCard: {
        backgroundColor: "white",
        borderRadius: 16,
        padding: 20,
        marginBottom: 24,
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.1,
        shadowRadius: 3.84,
        elevation: 5,
    },
    detailsTitle: {
        fontSize: 18,
        fontWeight: "bold",
        color: "#2c3e50",
        marginBottom: 16,
        borderBottomWidth: 1,
        borderBottomColor: "#ECF0F1",
        paddingBottom: 10,
    },
    detailRow: {
        flexDirection: "row",
        justifyContent: "space-between",
        marginBottom: 12,
    },
    detailLabel: {
        fontSize: 16,
        color: "#7f8c8d",
    },
    detailValue: {
        fontSize: 16,
        fontWeight: "500",
        color: "#2c3e50",
    },
    totalRow: {
        borderTopWidth: 1,
        borderTopColor: "#ECF0F1",
        paddingTop: 12,
        marginTop: 8,
    },
    totalLabel: {
        fontSize: 18,
        fontWeight: "bold",
        color: "#2c3e50",
    },
    totalValue: {
        fontSize: 18,
        fontWeight: "bold",
        color: "#27ae60",
    },
    dashboardButton: {
        backgroundColor: "#3498db",
        padding: 18,
        borderRadius: 12,
        alignItems: "center",
        marginTop: 8,
    },
    dashboardButtonText: {
        color: "white",
        fontSize: 18,
        fontWeight: "bold",
    },
});