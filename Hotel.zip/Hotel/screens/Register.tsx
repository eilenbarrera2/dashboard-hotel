import React, { useState } from "react";
import {
    View,
    Text,
    TextInput,
    TouchableOpacity,
    Image,
    StyleSheet,
    Alert,
    ScrollView,
    KeyboardAvoidingView,
    Platform,
    SafeAreaView
} from "react-native";
import { useNavigation } from "@react-navigation/native";


export default function Register() {
    const [form, setForm] = useState({
        name: "",
        email: "",
        password: "",
        confirmPassword: "",
    });
    const [showPassword, setShowPassword] = useState(false);
    const [showConfirmPassword, setShowConfirmPassword] = useState(false);

    const navigation = useNavigation<any>();

    const handleChange = (key: string, value: string) => {
        setForm({ ...form, [key]: value });
    };

    const handleSubmit = () => {
        if (form.password !== form.confirmPassword) {
            Alert.alert("Error", "Las contraseñas no coinciden");
            return;
        }
        Alert.alert("Éxito", "Cuenta creada exitosamente (simulación)");
        navigation.navigate("IniciarSesion"); // Corregido
    };

    return (
        <SafeAreaView style={styles.safeArea}>
            <KeyboardAvoidingView
                behavior={Platform.OS === "ios" ? "padding" : "height"}
                style={styles.keyboardAvoid}
            >
                <ScrollView
                    contentContainerStyle={styles.scrollContainer}
                    keyboardShouldPersistTaps="handled"
                >
                    <View style={styles.container}>
                        {/* Header */}
                        <View style={styles.header}>
                            <View style={styles.logoCircle}>
                                <Image source={require('./../assets/logo.png')} style={styles.logoImg} />
                            </View>
                            <Text style={styles.title}>Crear Cuenta</Text>
                            <Text style={styles.subtitle}>
                                Regístrate para comenzar a usar el sistema
                            </Text>
                        </View>

                        {/* Form */}
                        <View style={styles.form}>
                            <Text style={styles.label}>Nombre completo</Text>
                            <TextInput
                                style={styles.input}
                                placeholder="Ingresa tu nombre"
                                value={form.name}
                                onChangeText={(v) => handleChange("name", v)}
                            />

                            <Text style={styles.label}>Correo electrónico</Text>
                            <TextInput
                                style={styles.input}
                                placeholder="tu@email.com"
                                keyboardType="email-address"
                                autoCapitalize="none"
                                value={form.email}
                                onChangeText={(v) => handleChange("email", v)}
                            />

                            <Text style={styles.label}>Contraseña</Text>
                            <View style={styles.passwordContainer}>
                                <TextInput
                                    style={styles.inputPassword}
                                    placeholder="********"
                                    secureTextEntry={!showPassword}
                                    value={form.password}
                                    onChangeText={(v) => handleChange("password", v)}
                                />
                                <TouchableOpacity
                                    style={styles.eyeIconContainer}
                                    onPress={() => setShowPassword(!showPassword)}
                                >
                                    <Image
                                        source={showPassword ? require('./../assets/eye-open.png') : require('./../assets/eye-closed.png')}
                                        style={styles.eyeIcon}
                                    />
                                </TouchableOpacity>
                            </View>

                            <Text style={styles.label}>Confirmar contraseña</Text>
                            <View style={styles.passwordContainer}>
                                <TextInput
                                    style={styles.inputPassword}
                                    placeholder="********"
                                    secureTextEntry={!showConfirmPassword}
                                    value={form.confirmPassword}
                                    onChangeText={(v) => handleChange("confirmPassword", v)}
                                />
                                <TouchableOpacity
                                    style={styles.eyeIconContainer}
                                    onPress={() => setShowConfirmPassword(!showConfirmPassword)}
                                >
                                    <Image
                                        source={showConfirmPassword ? require('./../assets/eye-open.png') : require('./../assets/eye-closed.png')}
                                        style={styles.eyeIcon}
                                    />
                                </TouchableOpacity>
                            </View>

                            <TouchableOpacity style={styles.registerButton} onPress={handleSubmit}>
                                <Text style={styles.registerButtonText}>Crear cuenta</Text>
                            </TouchableOpacity>

                            <View style={styles.loginOption}>
                                <Text style={styles.text}>¿Ya tienes una cuenta? </Text>
                                <TouchableOpacity onPress={() => navigation.navigate("IniciarSesion")}>
                                    <Text style={styles.linkText}>Inicia sesión</Text>
                                </TouchableOpacity>
                            </View>
                        </View>
                    </View>
                </ScrollView>
            </KeyboardAvoidingView>
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    safeArea: {
        flex: 1,
        backgroundColor: "#eef3ff",
    },
    keyboardAvoid: {
        flex: 1,
    },
    scrollContainer: {
        flexGrow: 1,
        justifyContent: "center",
    },
    container: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
        paddingHorizontal: 20,
        paddingVertical: 20,
    },
    header: { alignItems: "center", marginBottom: 20 },
    logoCircle: {
        justifyContent: "center",
        alignItems: "center",
        backgroundColor: "#002a7f",
        width: 70,
        height: 70,
        borderRadius: 35,
        marginBottom: 10,
    },
    logoImg: { width: 50, height: 50, resizeMode: "contain" },
    title: { fontSize: 24, fontWeight: "bold", color: "#060e3a" },
    subtitle: { fontSize: 16, color: "#3d4046" },
    form: {
        backgroundColor: "white",
        padding: 25,
        borderRadius: 15,
        width: "100%",
        maxWidth: 350,
        shadowColor: "#000",
        shadowOpacity: 0.1,
        shadowRadius: 10,
        elevation: 3,
        marginBottom: 20,
    },
    label: { fontSize: 16, fontWeight: "600", color: "#060e3a", marginTop: 10 },
    input: {
        borderWidth: 1,
        borderColor: "#cbd5e1",
        borderRadius: 10,
        padding: 10,
        marginTop: 5,
        marginBottom: 10,
        height: 45,
    },
    passwordContainer: {
        flexDirection: "row",
        alignItems: "center",
        borderWidth: 1,
        borderColor: "#cbd5e1",
        borderRadius: 10,
        marginBottom: 15,
    },
    inputPassword: { flex: 1, padding: 10, height: 45 },
    eyeIconContainer: { paddingHorizontal: 10 },
    eyeIcon: { width: 22, height: 22, tintColor: "#333" },
    error: { color: "red", fontSize: 13, marginBottom: 10 },
    linkRight: { alignItems: "flex-end", marginBottom: 15 },
    linkText: { fontSize: 14, color: "#1d4ed8", fontWeight: "500" },
    registerButton: {
        backgroundColor: "#002a7f",
        padding: 12,
        borderRadius: 12,
        alignItems: "center",
        marginTop: 10,
    },
    registerButtonText: { color: "white", fontWeight: "bold", fontSize: 15 },
    loginOption: {
        flexDirection: "row",
        justifyContent: "center",
        marginTop: 20,
    },
    text: { fontSize: 14, color: "#333" },
});